globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/OYgETe5rQQgCmMHl9DzbS/_buildManifest.js",
    "static/OYgETe5rQQgCmMHl9DzbS/_ssgManifest.js",
    "static/OYgETe5rQQgCmMHl9DzbS/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1669h2xm3dy-c.js",
    "static/chunks/05cb37z0kpq1b.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0a1fuw9bg8yaq.js",
    "static/chunks/14~~ck7jdu-t6.js",
    "static/chunks/turbopack-04veba5tv2ami.js"
  ]
};
